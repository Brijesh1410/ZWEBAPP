﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ZWEBAPP.SERVICE.ADMIN;
using ZWEBAPP.SERVICE.CustomModel;

namespace ZWEBAPP.Controllers
{
    public class AdminController : Controller
    {
        public IAdminService adminService;

        public AdminController(IAdminService _adminService) {
            adminService = _adminService;
        }

        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult CheckLogin(Login loginData)
        {
            var adminUser = adminService.CheckLogin(loginData);
            if (adminUser != null)
            {
                return RedirectToAction("Home", "Admin");
            }
            else {
                ViewData["Responce"] = "Invalid Credentials.";
                return View("Login", loginData);
            }
        }

        public ActionResult Home()
        {
            return View();
        }
    }
}