﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ZWEBAPP.SERVICE.EMPLOYEE;

namespace ZWEBAPP.Controllers
{
    public class EmployeeController : Controller
    {

        public IEmployeeService employeeService;

        public EmployeeController(IEmployeeService _employeeService) {
            employeeService = _employeeService;
        }

        [HttpGet]
        public IActionResult Index()
        {
            var emps = employeeService.FillEmployees();
            return View(emps);
        }

        public IActionResult Edit(int id) {
            var emp = employeeService.GetEmployee(id);
            return View("Edit",emp);
        }

        [HttpPost]
        public IActionResult EditEmp(ZWEBAPP.SERVICE.CustomModel.Employee emp)
        {
            var emps = employeeService.EditEmployee(emp);
            return RedirectToAction("Index","Employee");
        }

    }
}