﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ZWEBAPP.DATA.Models;
using ZWEBAPP.SERVICE.CustomModel;

namespace ZWEBAPP.Models
{
    public static class ModelDomainMapper
    {
        public static void CreateMap()
        {
            AutoMapper.Mapper.Initialize(cfg =>
            {
                cfg.CreateMap<Admin, Login>();
                cfg.CreateMap<ZWEBAPP.DATA.Models.Employee, ZWEBAPP.SERVICE.CustomModel.Employee>()
                .ForMember(dst => dst.DepartmentName, opt => opt.MapFrom(src => src.Department.Name));

                cfg.CreateMap<ZWEBAPP.SERVICE.CustomModel.Employee, ZWEBAPP.DATA.Models.Employee>()
                .ForMember(dest => dest.Department, act => act.Ignore());
                //cfg.CreateMap<SRKAY.GovernanceTool.Entities.UserMaster, SRKAY.GovernanceTool.Data.Models.Usermaster>();

                /* etc */
            });
        }
    }

}
