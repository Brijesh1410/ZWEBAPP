﻿using System;
using System.Collections.Generic;
using System.Text;
using ZWEBAPP.SERVICE.CustomModel;

namespace ZWEBAPP.SERVICE.ADMIN
{
    public interface IAdminService
    {
        Login CheckLogin(Login adminCred);
    }
}
