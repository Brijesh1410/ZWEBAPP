﻿using System;
using System.Collections.Generic;
using System.Text;
using ZWEBAPP.DATA.Models;
using ZWEBAPP.SERVICE.CustomModel;
using System.Linq;
using AutoMapper;

namespace ZWEBAPP.SERVICE.ADMIN
{
    public class AdminService : IAdminService
    {
        MyDBContext db = new MyDBContext();

        public Login CheckLogin(Login adminCred)
        {
            try
            {
                var admin = db.Admin.Where(A => A.UserName == adminCred.UserName && A.Password == adminCred.Password).SingleOrDefault();
                if (admin != null) {
                    admin.LastLoginDate = DateTime.Now.ToString();
                    db.Admin.Update(admin);
                    db.SaveChanges();
                    return AutoMapper.Mapper.Map<Admin, Login>(admin);
                }
                return null;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
