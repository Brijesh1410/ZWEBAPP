﻿using System;
using System.Collections.Generic;
using System.Text;
using ZWEBAPP.DATA.Models;
using ZWEBAPP.SERVICE.CustomModel;
using System.Linq;
using AutoMapper;
using Microsoft.EntityFrameworkCore;

namespace ZWEBAPP.SERVICE.EMPLOYEE
{
    public class EmployeeService : IEmployeeService
    {
        MyDBContext db = new MyDBContext();

        public List<ZWEBAPP.SERVICE.CustomModel.Employee> FillEmployees()
        {
            try
            {
                var emps = db.Employee.Include(d=>d.Department).ToList();
                if (emps == null) {
                    return null;
                }
                return AutoMapper.Mapper.Map<List<ZWEBAPP.DATA.Models.Employee>,List<ZWEBAPP.SERVICE.CustomModel.Employee>>(emps);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public ZWEBAPP.SERVICE.CustomModel.Employee EditEmployee(ZWEBAPP.SERVICE.CustomModel.Employee emp)
        {
            try
            {
                var modelEmp = AutoMapper.Mapper.Map<ZWEBAPP.SERVICE.CustomModel.Employee,ZWEBAPP.DATA.Models.Employee>(emp);
                var emps = db.Employee.Update(modelEmp);
                db.SaveChanges();
                if (emps == null)
                {
                    return null;
                }
                return AutoMapper.Mapper.Map<ZWEBAPP.DATA.Models.Employee,ZWEBAPP.SERVICE.CustomModel.Employee>(emps.Entity);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public ZWEBAPP.SERVICE.CustomModel.Employee GetEmployee(int id) {
            try
            {
                var emps = db.Employee.Where(e => e.EmployeeId == id).SingleOrDefault();
                if (emps == null)
                {
                    return null;
                }
                return AutoMapper.Mapper.Map<ZWEBAPP.DATA.Models.Employee, ZWEBAPP.SERVICE.CustomModel.Employee>(emps);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}
