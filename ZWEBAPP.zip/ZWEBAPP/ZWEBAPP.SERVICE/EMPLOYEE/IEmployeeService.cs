﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ZWEBAPP.SERVICE.EMPLOYEE
{
    public interface IEmployeeService
    {
        List<ZWEBAPP.SERVICE.CustomModel.Employee> FillEmployees();
        ZWEBAPP.SERVICE.CustomModel.Employee EditEmployee(ZWEBAPP.SERVICE.CustomModel.Employee emp);
        ZWEBAPP.SERVICE.CustomModel.Employee GetEmployee(int Id); 
    }
}
