﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;

namespace ZWEBAPP.SERVICE.CustomModel
{
    public class Employee
    {
        [Key]
        public int EmployeeId { get; set; }

        [Required]
        public string Name { get; set; }

        [DataType(DataType.Date)]
        [Required]
        public DateTime? JoiningDate { get; set; }

        public string Gender { get; set; }

        [Required]
        public string Designation { get; set; }

        [DataType(DataType.EmailAddress,ErrorMessage ="Enter Valid Email Id")]
        [Required]
        public string Email { get; set; }

        [DataType(DataType.ImageUrl)]
        public string ProfileImage { get; set; }


        public string Bio { get; set; }

        [DataType(DataType.Url)]
        [Required]
        public string FaceBookProfileUrl { get; set; }

        [Required]
        public int? DepartmentId { get; set; }

        public string DepartmentName { get; set; }
    }
}
