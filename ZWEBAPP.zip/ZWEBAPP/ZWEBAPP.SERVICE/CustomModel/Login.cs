﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;

namespace ZWEBAPP.SERVICE.CustomModel
{
    public class Login
    {

        public int AdminId { get; set; }

        [Required]
        public string UserName { get; set; }

        [DataType(DataType.Password)]
        [Required]
        public string Password { get; set; }

        public string LastLoginDate { get; set; }
    }
}
